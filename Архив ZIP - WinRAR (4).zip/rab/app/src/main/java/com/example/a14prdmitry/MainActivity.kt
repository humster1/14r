package com.example.a14prdmitry

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private lateinit var trueButton: Button
    private lateinit var falseButton: Button
    private lateinit var quesText : TextView
    private lateinit var next : Button
    private lateinit var prev : Button
    private var index = 0
    private val quesAll = listOf(){
        Quesn(R.string.ques, true)
        Quesn(R.string.ques2, true)
        Quesn(R.string.ques3, true)
        Quesn(R.string.ques4, true)
        Quesn(R.string.ques5, true)
        Quesn(R.string.ques6, true)
        Quesn(R.string.ques7, true)
    }

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        trueButton = findViewById(R.id.button_true)
        falseButton = findViewById(R.id.button_false)
        n = findViewById(R.id.)
    }

}
