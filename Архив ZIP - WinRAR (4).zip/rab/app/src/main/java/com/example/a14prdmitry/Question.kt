package com.example.a14prdmitry;
import android.support.annotation.StringRes
data class Quesn(@StringRes val textResId: Int, val answer: Boolean){}
