package com.example.pr14

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class TestProdoljenie : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test_prodoljenie)
    }
}