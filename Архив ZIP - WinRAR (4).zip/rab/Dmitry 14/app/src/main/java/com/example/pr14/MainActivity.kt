package com.example.pr14

import android.annotation.SuppressLint
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private lateinit var trueButton: Button
    private lateinit var falseButton: Button
    private lateinit var nextButton:Button
    private lateinit var questionTextView:TextView

    private val questionBank = listOf(
        Question(R.string.vopr1,true),
        Question(R.string.vopr2,true),
        Question(R.string.vopr3,true),
        Question(R.string.vopr4,true),
        Question(R.string.vopr5,false))

    private var currentIndex = 0


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        trueButton = findViewById(R.id.true_button)
        falseButton = findViewById(R.id.false_button)
        nextButton = findViewById(R.id.next)
        questionTextView = findViewById(R.id.text)

        trueButton.setOnClickListener{view:View ->
            val Toast = Toast.makeText(this,R.string.correct,Toast.LENGTH_SHORT)
            Toast.setGravity(Gravity.TOP,0,100)
            Toast.show()
           checkAnswer(true)
        }
        falseButton.setOnClickListener{view:View->
            val Toast = Toast.makeText(this,R.string.incorrect,Toast.LENGTH_SHORT)
            Toast.setGravity(Gravity.TOP,0,1800)
            Toast.show()
            checkAnswer(false)
        }
        val questionTextReId = questionBank[currentIndex].textResId
        questionTextView.setText(questionTextReId)


        nextButton.setOnClickListener{ currentIndex = (currentIndex+1) %
                questionBank.size
            updateQuestion()
        }
        updateQuestion()
    }
    private fun updateQuestion(){
        val qyestionTextResId = questionBank[currentIndex].textResId
        questionTextView.setText(qyestionTextResId)


    }
    private fun checkAnswer(userAnswer: Boolean){
        val correctAnswer = questionBank[currentIndex].answer

        val messageResId = if (userAnswer == correctAnswer){
            R.string.correct
        }else{
            R.string.incorrect
        }

            Toast.makeText(this,messageResId,Toast.LENGTH_SHORT)
                .show()
    }


}